// listing model placeholder
