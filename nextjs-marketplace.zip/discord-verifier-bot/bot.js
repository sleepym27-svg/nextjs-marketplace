// bot placeholder
