// listing detail placeholder
