// discord verify placeholder
