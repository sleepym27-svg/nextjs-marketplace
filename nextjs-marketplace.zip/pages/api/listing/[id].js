// single listing api placeholder
