// discord auth placeholder
