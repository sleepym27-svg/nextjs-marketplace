// stripe checkout placeholder
